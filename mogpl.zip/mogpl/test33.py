#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 17:22:49 2018

@author: 3520413
"""

from numpy import arange,array,ones,linalg 
from pylab import plot,show

xi = array([4,17,37,55,88,96])
A = array([xi,ones(6)])
# linearly generated sequence 
y = [11,25,46,48,65,71]
# obtaining the parameters 
w = [0.5822784810126582, 15.10126582278481]
# plotting the line 
line = [17.430379746835442, 25.0, 36.64556962025317, 47.12658227848101, 66.34177215189874, 71.0]
 # regresion line 
plot(xi,line,'r-',xi,y,'o')
show()