#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 17:34:52 2018

@author: 3520413
"""

from gurobipy import *


m = Model("mogplex1") # declaration du modele 
# declaration des variables

    
x = []
for i in range(3):
    x.append(m.addVar(vtype=GRB.CONTINUOUS))


m.update() # finaliser la déclaration des variables 

# former l'objectif
obj = LinExpr() 
obj=3*x[0]+4*x[1]
# ajouter l'objectif dans le modele 
m.setObjective(obj,GRB.MINIMIZE)

# former les contraintes 
m.addConstr(2*x[0]+3*x[1]>=8)
m.addConstr(x[0]+x[1]>=5)
    
# resolution 
m.optimize()

print(x)

    
    


