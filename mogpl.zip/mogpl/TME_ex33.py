#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Oct 22 16:29:03 2018

@author: 3520413
"""

#from numpy import arange,array,ones,linalg 
#from pylab import plot,show

#xi = array([4,17,37,55,88,96])
#A = array([xi,ones(6)])
## linearly generated sequence 
#y = [11,25,46,48,65,71]
## obtaining the parameters 
#w = linalg.lstsq(A.T,y)[0]
## plotting the line 
#line = w[0]*xi+w[1] # regresion line 
#plot(xi,line,'r-',xi,y,'o')
#show()
#
#xi = array([4,17,37,55,88,14])
#A = array([xi,ones(6)])
## linearly generated sequence 
#y = [11,25,46,48,65,97]
## obtaining the parameters 
#w = linalg.lstsq(A.T,y)[0]
## plotting the line 
#line = w[0]*xi+w[1] # regresion line 
##plot(xi,line,'r-',xi,y,'o')
##show()


from gurobipy import *

xi = [4,17,37,55,88,14]
y = [11,25,46,48,65,97]

m = Model("mogplex1") # declaration du modele 
# declaration des variables
w = []
for i in range(2):
    w.append(m.addVar(vtype=GRB.CONTINUOUS))
u = []
for i in range(6):
    u.append(m.addVar(vtype=GRB.CONTINUOUS,lb=0))

m.update() # finaliser la déclaration des variables 

# former l'objectif
obj = LinExpr() 
obj=0
for i in range(6):
    obj+=u[i]
# ajouter l'objectif dans le modele 
m.setObjective(obj,GRB.MINIMIZE)

# former les contraintes 
for i in range(6):
    m.addConstr(u[i]-y[i]+w[0]*xi[i]+w[1]>=0)
    m.addConstr(u[i]+y[i]-w[0]*xi[i]-w[1]>=0)
    
# resolution 
m.optimize()

line = []
for i in range(len(xi)):
    line.append((w[0].x)*xi[i] + w[1].x)
    
print(line)
print(w[0].x,w[1].x)

# acces a la solution optimale :
# la valeur de la variable w0 est obtenue par w[0].x, de meme pour w1 avec w[1].x
# donc droite de regression definie par line = w[0].x*xi + w[1].x

 
    

    
